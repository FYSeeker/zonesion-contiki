#ifndef _sensor_process_h_
#define _sensor_process_h_

#include "contiki.h"
#include "sensor.h"

#endif